package com.example.amazon_web_api_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonWebApiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
